﻿using System;

namespace Integration
{
    public class PatentCitation
    {
        public int Sequence { get; set; }

        public string Authority { get; set; }

        public string Number { get; set; }

        public string Kind { get; set; }

        public string Date { get; set; }

        public string Applicant { get; set; }
    }
}