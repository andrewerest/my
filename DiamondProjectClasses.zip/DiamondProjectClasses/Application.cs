﻿using System;

namespace Integration
{
    public class Application
    {
        public string Number { get; set; }

        public string Date { get; set; }

        public string Language { get; set; }

        /*need to be checked if next two dates are displayed in diamond*/
        public string OtherDate { get; set; }

        public string EffectiveDate { get; set; }
    }
}