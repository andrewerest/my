﻿using System;

namespace Integration
{
    public class Priority
    {
        public int? Sequence { get; set; }

        public string Country { get; set; }

        public string Number { get; set; }

        public string Date { get; set; }
    }
}