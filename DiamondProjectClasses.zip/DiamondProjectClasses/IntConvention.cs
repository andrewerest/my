﻿using System;
using System.Collections.Generic;

namespace Integration
{
    public class IntConvention
    {
        public string PctNationalDate { get; set; }

        public string PctApplNumber { get; set; }

        public string PctApplDate { get; set; }

        public string PctPublNumber { get; set; }

        public string PctPublDate { get; set; }

        public List<string> DesignatedStates { get; set; }
    }
}