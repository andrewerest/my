﻿namespace Integration
{
    public class NoteTranslation
    {
        public string Tr { get; set; }
        public string Type { get; set; }
        public string Language { get; set; }
    }
}
