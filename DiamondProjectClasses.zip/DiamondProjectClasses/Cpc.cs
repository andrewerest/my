﻿using System;

namespace Integration
{
    public class Cpc
    {
        public int Sequence { get; set; }

        public string Group { get; set; }

        public string Rank { get; set; }

        public string Office { get; set; }

        public string Schema { get; set; }

        public string SchemaDate { get; set; }

        public string Class { get; set; }

        public string Position { get; set; }

        public string Value { get; set; }

        public string Status { get; set; }

        public string Source { get; set; }

        public string GeneratingOffice { get; set; }

        public string ActionDate { get; set; }
    }
}