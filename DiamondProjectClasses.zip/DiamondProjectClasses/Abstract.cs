﻿using System;

namespace Integration
{
    public class Abstract
    {
        public string Language { get; set; }

        public string Text { get; set; }
    }
}