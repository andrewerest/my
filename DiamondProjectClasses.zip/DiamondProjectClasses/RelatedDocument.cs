﻿using System;

namespace Integration
{
    public class RelatedDocument
    {
        public string Source { get; set; }

        public string Format { get; set; }

        public string Type { get; set; }

        public string Number { get; set; }

        public string Date { get; set; }
    }
}