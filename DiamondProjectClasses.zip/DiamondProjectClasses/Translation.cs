﻿namespace Integration
{
    public class Translation
    {
        public string Type { get; set; }

        public string TrName { get; set; }

        public string Language { get; set; }

        public string TrAddress1 { get; set; }
    }
}