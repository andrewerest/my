﻿using System;

namespace Integration
{
    public class Ipc
    {
        public int? Edition { get; set; }

        public string Class { get; set; }

        public string Date { get; set; }
    }
}