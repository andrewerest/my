﻿namespace Integration
{
    public class Title
    {
        public string Language { get; set; }
        public string Text { get; set; }
    }
}