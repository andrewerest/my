﻿namespace Integration
{
    public class NonPatentCitation
    {
        public int Sequence { get; set; }

        public string Text { get; set; }

        public string XpNumber { get; set; }
    }
}