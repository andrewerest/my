﻿using System;
namespace Integration
{
    public class Ipcr
    {
        public int Sequence { get; set; }

        public string ClassRaw { get; set; }

        public string Section { get; set; }

        public string Subclass { get; set; }

        public string Maingroup { get; set; }

        public string Subgroup { get; set; }

        public string Classscheme { get; set; }

        public string ClassValue { get; set; }

        public string ActionDate { get; set; }

        public string ClassStatus { get; set; }

        public string ClassDataSource { get; set; }

        public string Office { get; set; }
    }
}